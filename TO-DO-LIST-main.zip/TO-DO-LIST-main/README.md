# TO-DO-LIST

TO-DO-LIST (Made using HTML5 CSS3 and JavaScript)

You can see the website live at: https://5codeman.github.io/TO-DO-LIST/

ABOUT THIS PROJECT-:

  1. In this project i have created a simple to-do app using HTML CSS and JavaScript.
  2. Built a To-Do List application to make a list of daily works written down in one place.
  3. Implemented functionalities like add task, remove task, filter tasks and also mark tasks as done.
 
